/*
 * the aim is to let apk run on 32-bit running space
 */
int em_platform32_dummy_func() {
    /* just do nothing */
    return 0;
}
